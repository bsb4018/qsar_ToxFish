from setuptools import setup, find_packages

setup(
    name="src",
    version="0.1",
    description="Fish Toxicity Project", 
    author="bsb4018", 
    packages=find_packages(),
    license="MIT"
)